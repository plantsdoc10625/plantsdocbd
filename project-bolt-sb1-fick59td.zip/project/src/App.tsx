import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Shop from './components/Shop';
import Gallery from './components/Gallery';
import Blog from './components/Blog';
import Booking from './components/Booking';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <Hero />
            <About />
            <div className="py-16 bg-green-50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-3xl font-bold text-gray-900 mb-8">Choose Your Path</h2>
                <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                  <button
                    onClick={() => setCurrentPage('services')}
                    className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-green-200 hover:border-green-400"
                  >
                    <div className="text-green-600 text-6xl mb-4">🌱</div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Services</h3>
                    <p className="text-gray-600">Expert plant care, consultation, and agricultural solutions</p>
                  </button>
                  <button
                    onClick={() => setCurrentPage('shop')}
                    className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-green-200 hover:border-green-400"
                  >
                    <div className="text-green-600 text-6xl mb-4">🛒</div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">Shop Now</h3>
                    <p className="text-gray-600">Premium plants, seeds, and gardening supplies</p>
                  </button>
                </div>
              </div>
            </div>
            <Gallery />
          </>
        );
      case 'about':
        return <About />;
      case 'services':
        return <Services />;
      case 'shop':
        return <Shop />;
      case 'gallery':
        return <Gallery />;
      case 'blog':
        return <Blog />;
      case 'booking':
        return <Booking />;
      case 'contact':
        return <Contact />;
      default:
        return <Hero />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
      <Footer setCurrentPage={setCurrentPage} />
    </div>
  );
}

export default App;